class Spider(object):
    """Standalone（非 Chaquopy）Python 爬虫基类：只保留 TVBox 需要的接口。"""

    def __init__(self):
        self.extend = ''

    def init(self, extend=""):
        pass

    def homeContent(self, filter):
        return {}

    def homeVideoContent(self):
        return {}

    def categoryContent(self, tid, pg, filter, extend):
        return {}

    def detailContent(self, ids):
        return {}

    def searchContent(self, key, quick, pg="1"):
        return {}

    def playerContent(self, flag, vid, vipFlags=None):
        return {}

    def liveContent(self, url):
        return {}

    def getProxyUrl(self, *args):
        return "http://127.0.0.1:9978/proxy?do=py&siteKey=" + (getattr(self, "siteKey", "") or "")

    def localProxy(self, param):
        return None
