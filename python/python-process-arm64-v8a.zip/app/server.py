"""TVBox Python 运行时（独立进程）：把 spider 的 JSON 接口暴露成本地 HTTP。"""

import base64
import json
import os
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN = os.environ.get("TVBOX_TOKEN", "")
STATE = {"spider": None}


def load_source(api):
    if api.startswith(("http://", "https://")):
        import requests
        response = requests.get(api, timeout=20)
        response.raise_for_status()
        return response.text
    with open(api, "r", encoding="utf-8") as handle:
        return handle.read()


def build_spider(api):
    namespace = {"__name__": "tvbox_spider", "__file__": api}
    exec(compile(load_source(api), api, "exec"), namespace)
    cls = namespace.get("Spider")
    if cls is None:
        raise RuntimeError("python spider 缺少 Spider 类")
    return cls()


def call(name, *args):
    spider = STATE["spider"]
    if spider is None:
        raise RuntimeError("spider 未初始化，先调用 /init")
    value = getattr(spider, name)(*args)
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)


ROUTES = {
    "/init": lambda body: (STATE.__setitem__("spider", build_spider(body["api"])),
                           STATE["spider"].init(body.get("ext", ""))) and "",
    "/home": lambda body: call("homeContent", body.get("filter", True)),
    "/homeVod": lambda body: call("homeVideoContent"),
    "/search": lambda body: call("searchContent", body.get("wd", ""), body.get("quick", False),
                                 body.get("page", "1")),
    "/detail": lambda body: call("detailContent", [body.get("id", "")]),
    "/play": lambda body: call("playerContent", body.get("flag", ""), body.get("id", ""), []),
    "/category": lambda body: call("categoryContent", body.get("tid", ""), body.get("page", "1"),
                                   body.get("filter", True), body.get("extend") or {}),
    "/live": lambda body: call("liveContent", body.get("url", "")),
}




def handle_proxy(params):
    spider = STATE["spider"]
    if spider is None:
        return 500, "text/plain", {}, b"spider not initialized"
    result = spider.localProxy(params)
    if result is None:
        return 404, "text/plain", {}, b"not found"
    headers = {}
    base64_flag = False
    if isinstance(result, dict):
        code = int(result.get("code", 200) or 200)
        ctype = result.get("content_type") or result.get("type") or "application/octet-stream"
        headers = dict(result.get("header") or result.get("headers") or {})
        if result.get("url"):
            headers["Location"] = result["url"]
            return (code if code != 200 else 302), ctype, headers, b""
        data = result.get("content") or b""
    else:
        code = int(result[0])
        ctype = str(result[1])
        data = result[2]
        if len(result) > 3 and result[3]:
            headers = dict(result[3])
        if len(result) > 4:
            base64_flag = int(result[4]) == 1
    if base64_flag:
        data = base64.b64decode(data)
    elif isinstance(data, str):
        data = data.encode("utf-8")
    return code, ctype, headers, data or b""

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def send_json(self, code, text):
        data = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/ping"):
            self.send_json(200, json.dumps({"ok": True, "version": sys.version.split()[0]}))
        else:
            self.send_json(404, "{}")

    def send_proxy(self, params):
        code, ctype, headers, data = handle_proxy(params)
        self.send_response(200)
        self.send_header("X-TV-Code", str(code))
        self.send_header("X-TV-Type", ctype or "application/octet-stream")
        self.send_header("X-TV-Headers", json.dumps(headers or {}, ensure_ascii=False))
        self.send_header("Content-Type", ctype or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if TOKEN and self.headers.get("X-Token") != TOKEN:
            self.send_json(403, "{}")
            return
        path = self.path.split("?")[0]
        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(length) or b"{}")
            if path == "/proxy":
                self.send_proxy(body)
                return
            route = ROUTES.get(path)
            if route is None:
                self.send_json(404, "{}")
                return
            if path == "/init":
                STATE["siteKey"] = body.get("siteKey", "")
            result = route(body)
            self.send_json(200, result if isinstance(result, str) else json.dumps(result, ensure_ascii=False))
        except Exception as error:  # noqa: BLE001 - 统一转成 JSON 错误
            traceback.print_exc()
            self.send_json(500, json.dumps({"error": str(error)}, ensure_ascii=False))


def main():
    port = int(os.environ.get("TVBOX_PORT", "0"))
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print("TVBOX_READY %d" % server.server_address[1], flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
